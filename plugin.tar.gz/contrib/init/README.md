Sample configuration files for:

SystemD: ariad.service
Upstart: ariad.conf
OpenRC:  ariad.openrc
         ariad.openrcconf
CentOS:  ariad.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
