#!/bin/bash
# Copyright (c) 2017-2018 The AriA Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

BUILDDIR="/home/mini/aria"
EXEEXT=".exe"

# These will turn into comments if they were disabled when configuring.
ENABLE_ARIAD=1

REAL_ARIAD="$BUILDDIR/src/ariad${EXEEXT}"

